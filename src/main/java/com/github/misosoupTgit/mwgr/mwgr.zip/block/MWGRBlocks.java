package com.github.misosoupTgit.mwgr.block;

import com.github.misosoupTgit.mwgr.MWGRMod;
import com.github.misosoupTgit.mwgr.item.MWGRColorBlockItems;
import com.github.misosoupTgit.mwgr.item.MWGRItems;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.Fluids;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;
import java.util.function.Supplier;

public class MWGRBlocks {
    public static final DeferredRegister<Block> BLOCKS =
            DeferredRegister.create(ForgeRegistries.BLOCKS, MWGRMod.MOD_ID);

    public static final RegistryObject<Block> WATER_GENERATOR = registryBlockItem(
            "water_generator",
            () -> new FluidGeneratorBlock(BlockBehaviour.Properties.of()
                    .mapColor(Blocks.IRON_BLOCK.defaultMapColor())
                    .strength(0.8f, 128.0f)
                    .sound(SoundType.STONE),
                    MWGRBlockEntities.WATER_GENERATOR_BE, Fluids.WATER),
            "#00AAFF", true
    );

    public static final RegistryObject<Block> LAVA_GENERATOR = registryBlockItem(
            "lava_generator",
            () -> new FluidGeneratorBlock(BlockBehaviour.Properties.of()
                    .mapColor(Blocks.STONE.defaultMapColor())
                    .strength(0.8f, 128.0f)
                    .sound(SoundType.STONE),
                    MWGRBlockEntities.LAVA_GENERATOR_BE, Fluids.LAVA),
            "#FF4400", true
    );

    private static <T extends Block> RegistryObject<T> registryBlockItem(String name, Supplier<T> supplier, String hexColor, boolean isBold) {
        RegistryObject<T> block = BLOCKS.register(name, supplier);
        MWGRItems.ITEMS.register(name, () -> new MWGRColorBlockItems(block.get(), new Item.Properties(), hexColor, isBold));
        return block;
    }

    public static void register(IEventBus eventBus) {
        BLOCKS.register(eventBus);
    }
}