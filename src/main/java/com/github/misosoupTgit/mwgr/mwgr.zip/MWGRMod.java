package com.github.misosoupTgit.mwgr;

import com.github.misosoupTgit.mwgr.block.MWGRBlockEntities;
import com.github.misosoupTgit.mwgr.block.MWGRBlocks;
import com.github.misosoupTgit.mwgr.config.MWGRConfig;
import com.github.misosoupTgit.mwgr.item.MWGRItems;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.ModLoadingContext;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.config.ModConfig;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;

@Mod(MWGRMod.MOD_ID)
public class MWGRMod {
    public static final String MOD_ID = "mwgr";

    public String getModId() {
        return MOD_ID;
    }

    public MWGRMod() {
        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();

        // Configの登録 (ここが漏れているとクラッシュします)
        ModLoadingContext.get().registerConfig(ModConfig.Type.SERVER, MWGRConfig.SPEC);

        MWGRBlocks.register(bus);
        MWGRItems.register(bus);
        MWGRBlockEntities.register(bus);
    }
}