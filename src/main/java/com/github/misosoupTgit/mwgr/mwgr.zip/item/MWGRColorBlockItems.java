package com.github.misosoupTgit.mwgr.item;

import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.TextColor;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.Block;
import org.jetbrains.annotations.NotNull;

public class MWGRColorBlockItems extends BlockItem {
    private final int hexColor;
    private final boolean isBold;

    public MWGRColorBlockItems(Block block, Properties properties, String hexColorString, boolean isBold) {
        super(block, properties);
        this.hexColor = Integer.decode(hexColorString);
        this.isBold = isBold;
    }

    @Override
    public @NotNull Component getName(@NotNull ItemStack stack) {
        return Component.translatable(this.getDescriptionId())
                .withStyle(style -> style
                        .withColor(TextColor.fromRgb(hexColor))
                        .withBold(isBold)   // 指定された太字設定を適用
                        .withItalic(false)); // 斜体は一律解除
    }
}