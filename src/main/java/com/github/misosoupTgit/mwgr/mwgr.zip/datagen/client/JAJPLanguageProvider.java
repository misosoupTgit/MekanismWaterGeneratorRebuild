package com.github.misosoupTgit.mwgr.datagen.client;

import com.github.misosoupTgit.mwgr.MWGRMod;
import com.github.misosoupTgit.mwgr.block.MWGRBlocks;
import net.minecraft.data.PackOutput;
import net.minecraftforge.common.data.LanguageProvider;

import java.util.Locale;

public class JAJPLanguageProvider extends LanguageProvider {
    public JAJPLanguageProvider(PackOutput output) {
        super(output, MWGRMod.MOD_ID, Locale.JAPAN.toString().toLowerCase());
    }

    @Override
    protected void addTranslations() {
        addBlock(MWGRBlocks.WATER_GENERATOR, "水生成機");
        addBlock(MWGRBlocks.LAVA_GENERATOR, "溶岩生成機");
        add("message.mwgr.auto_eject.on", "§3自動搬出: 有効");
        add("message.mwgr.auto_eject.off", "§c自動搬出: 無効");

        add("advancements.mwgr.get_water_gen.title", "タービンいらず");
        add("advancements.mwgr.get_water_gen.description", "水生成機を入手する");

        add("advancements.mwgr.get_lava_gen.title", "PCに優しい黒曜石量産方法");
        add("advancements.mwgr.get_lava_gen.description", "溶岩生成機を入手する");
    }
}
