package com.github.misosoupTgit.mwgr.datagen.client;

import com.github.misosoupTgit.mwgr.MWGRMod;
import com.github.misosoupTgit.mwgr.block.MWGRBlocks;
import net.minecraft.data.PackOutput;
import net.minecraftforge.common.data.LanguageProvider;

import java.util.Locale;

public class ENUSLanguageProvider extends LanguageProvider {
    public ENUSLanguageProvider(PackOutput output) {
        super(output, MWGRMod.MOD_ID, Locale.US.toString().toLowerCase());
    }

    @Override
    protected void addTranslations() {
        addBlock(MWGRBlocks.WATER_GENERATOR, "Water Generator");
        addBlock(MWGRBlocks.LAVA_GENERATOR, "Lava Generator");
        add("message.mwgr.auto_eject.on", "§3Auto Eject: On");
        add("message.mwgr.auto_eject.off", "§cAuto Eject: Off");

        add("advancements.mwgr.get_water_gen.title", "No Turbines Required");
        add("advancements.mwgr.get_water_gen.description", "Obtain a water generator");

        add("advancements.mwgr.get_lava_gen.title", "PC-Friendly Obsidian Farming Method");
        add("advancements.mwgr.get_lava_gen.description", "Obtain a Lava Generator");
    }
}
